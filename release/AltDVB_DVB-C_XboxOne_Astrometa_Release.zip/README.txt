========================================================================
Drivere Native WinUSB pentru AltDVB v2.5
Microsoft Xbox One Digital TV Tuner & Astrometa DVB-T2/C USB Stick
Versiune: Noiembrie 2026 (Fix QAM-256 / 0-Drop TS Buffer / Fast Zapping)
Autor: zildan & Comunitatea DVB
========================================================================

CONTINUT ARHIVA:
1. Dev_DVB_Cable_Unified.int + .cfg
   -> Driver UNIFICAT 2-in-1: detecteaza automat si suporta atat tunerul 
      Xbox One cat si Astrometa DVB-T2/C Stick intr-un singur modul.
      Permite comutarea usoara in AltDVB fara a schimba DLL-ul de device.

2. Dev_XboxOne_QAM256.int + .cfg
   -> Modul DEDICAT standalone pentru Microsoft Xbox One Tuner (045E:02D5).
      Optimizat strict pentru puntea DiB0700 + Panasonic MN88472 + TDA18250.

3. Dev_Astrometa_DVB.int + .cfg
   -> Modul DEDICAT standalone pentru Astrometa DVB-T2/C USB Stick (15F4:0131).
      Optimizat pentru RTL2832P + Panasonic MN88473 + Rafael Micro R828D.

4. dvb-usb-dib0700-1.20.fw & dvb-demod-mn88472-02.fw
   -> Fisierele de firmware originale necesare pentru initializarea 
      tunerului Xbox One (se incarca automat de catre driver in RAM-ul tunerului).

========================================================================
CERINTE SI INSTALARE DRIVER USB (ZADIG):
========================================================================
Pentru ca AltDVB sa comunice direct cu tunerele prin WinUSB la latenta 0:
1. Descarcati aplicatia Zadig (https://zadig.akeo.ie/).
2. Conectati tunerul in portul USB.
3. In Zadig:
   - Bifati 'Options' -> 'List All Devices'.
   - Selectati din lista tunerul:
     * Pentru Xbox One: 'Xbox One Digital TV Tuner' (VID 045E, PID 02D5)
     * Pentru Astrometa: 'DVB-T2/C' sau 'Bulk-In, Interface (Interface 0)' (VID 15F4, PID 0131)
   - La 'Target Driver' selectati: 'WinUSB' (v6.1.7600 sau mai nou).
   - Apasati 'Replace Driver' / 'Install Driver'.

========================================================================
INSTALARE IN ALTDVB v2.5:
========================================================================
1. Copiati toate fisierele din aceasta arhiva direct in folderul:
   <Folderul_AltDVB>\Devices\

2. Porniti aplicatia AltDVB (AltDVB.exe).
3. La pornire sau din meniul Settings -> Device:
   - Daca folositi 'Dev_DVB_Cable_Unified.int':
     Selectati slotul dorit (Xbox One sau Astrometa).
   - Sau selectati modulul dedicat preferat.
4. Scanati frecventele DVB-C dorite (ex: reteaua DIGI Romania - SR 6900, QAM-64 / QAM-256).

========================================================================
CE ADUCE NOU ACEASTA VERSIUNE:
========================================================================
* Zero Packet Drops la QAM-256: rezolvata definitiv problema istorica a 
  frame-drop-urilor pe transponderele 256-QAM cu bitrate mare (DIGI 4K, 
  canale HD).
* Resincronizare rapida pe MPEG-TS (0x47): tranzitie instantanee la 
  zapping fara erori sau dezaliniere de flux.
* Astrometa Zapping Fix: eliminat complet conflictul de magistrala USB 
  care bloca tunerul R828D la schimbarea frecventelor (nu mai ramane ecran negru).
* Monitorizare semnal adaptiva: suport complet pentru hot-plug cablu TV 
  si detectie semnal SNR / Strength in timp real.
